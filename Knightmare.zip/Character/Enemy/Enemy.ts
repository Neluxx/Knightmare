namespace Game {

  export class Enemy extends Character {
    public moveLeft: boolean = true;

    constructor() {
      super();
    }
  }
}